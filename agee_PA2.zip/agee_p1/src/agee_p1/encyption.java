package agee_p1;

import java.util.Scanner;
public class encyption {
	static int users;
	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		//scnr.close();
	System.out.print("Enter four digit number: ");
	int getInput = scnr.nextInt();
	
	int a = getInput / 1000;
	int b = (getInput%1000) /100;
	int c = (getInput % 100) / 10;
	int d = getInput % 10;
	
	
	a = (a + 7) % 10;
	b = (b + 7) % 10;
	c = (c + 7) % 10;
	d = (d + 7) % 10;
	
	int encrypt = (c * 1000 + d * 100 + a * 10 + b);
	
	System.out.print("Encrpyted number is: ");
	System.out.println(c * 1000 + d * 100 + a * 10 + b);
	
	
	int a1 = (a + 3) % 10;
	int b1 = (b + 3) % 10;
	int c1 = (c + 3) % 10;
	int d1 = (d + 3) % 10;
	
	int decrypt = (c1 * 1000 + d1 * 100 + a1 * 10 + b1);
	System.out.print("Number after decryption is: ");
	System.out.print(a1 * 1000 + b1 * 100 + c1 * 10 + d1);
	}

}
