package agee_p2;

import java.util.Scanner;
public class bmi {
	static int users;
	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		
	double lbs;
	double inch;
	double kilo;
	double BMI = 0;
	double meters;
	
	System.out.println("Choose which option for heigh and weight: 1. (lbs/inches) or 2. (kilo/meters)");
	int choice = scnr.nextInt();
	
	if(choice == 1) {
		System.out.println("Enter Height in inches: ");
		inch = scnr.nextDouble();
		System.out.println("Enter weight in pounds: ");
		lbs = scnr.nextDouble();
		BMI = (703*lbs)/(inch*inch);
		}	
	else if(choice == 2) {
		System.out.println("Enter Height in meters: ");
		meters = scnr.nextDouble();
		System.out.println("Enter weight in kilograms: ");
		kilo = scnr.nextDouble();
		BMI = kilo /(meters*meters);
		}
	else{
		System.out.print("not an option, goodbye!");
		return;
		}
	
	if(BMI <= 18.5) {
		System.out.println("BMI < 18.5 = UnderWeight");
		}
	else if(BMI <= 24.9) {
		System.out.println("BMI 18.5-24.9 = Healthy");
		}
	else if(BMI <= 29.9) {
		System.out.println("BMI 25-29.9 = Overweight");
		}
	else{
		System.out.println("BMI >  30.0 = obese");
		}
		
				
	
		
		
	
	
	}
}
