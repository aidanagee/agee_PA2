package agee_p3;

import java.util.Scanner;
public class rating {
	static int users;
	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
	
	int [][]a = new int[5][10];
	String[]s= {"Taco Laws ", "Arugula Conspiracy ", "Jello Shots ", "Gas Station Pills ","Vintage Modernism "};
	
	double[] total = new double[] {0,0,0,0,0};
	double average = 0;
	double big = total[0];
	double small = total[0];
	int big1 = 0;
	int small1 = 0;
	int ask = 0;
	
	
	System.out.print("How many people are taking this survey?: ");
	ask = scnr.nextInt();	
	
	for(int i=0; i<ask; i++){
		
	       for(int j=0;j<5;j++){
	    	   
	           System.out.println("Rate between 1-10\n"+(j+1)+"."+s[j]);
	           a[j][i]=scnr.nextInt();
	       }
	   }
	
	System.out.println("Here are the results.");
	  for(int i=0; i<5; i++){		  
	    System.out.print("\n "+ (i+1) + "." + s[i]);
	    
	     	for(int j=0; j<ask; j++){
	         System.out.print(a[i][j] + "\t");
	         total[i] = total[i] + a[i][j];
	       		}
	     	
	       average = total[i]/10;
	       System.out.println("Average = " + average);
	   }
	
	  
	 for(int i = 0; i <5; i++) {
		 if(big < total[i]) {
			 big = total[i];
			 big1 = i;
		 		}
		 if(small > total[0]) {
			 small = total[0];
			 small1 = i;
			 	}	 	 	 
	 }
	System.out.println("Highest Point Total   |" + s[big1] + "|     Rating:" + big); 	
	System.out.println("Lowest Point Total   |" + s[small1] + "|     Rating:" + small);
	
	}
}
